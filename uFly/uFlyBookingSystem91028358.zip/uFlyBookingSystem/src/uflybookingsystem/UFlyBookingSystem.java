/*
 * Main class that starts up the application's Main form 
 */
package uflybookingsystem;

public class UFlyBookingSystem {


    public static void main(String[] args) {
        MainForm mainForm = new MainForm();
        mainForm.setVisible(true);
    }    
}
